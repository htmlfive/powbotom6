package org.powbot.om6.salvager

fun main() {
    val script = ShipwreckSalvager()
    script.startScript("localhost", "0m6", false)
}