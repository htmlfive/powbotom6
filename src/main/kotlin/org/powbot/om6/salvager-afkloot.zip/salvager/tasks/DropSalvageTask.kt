package org.powbot.om6.salvager.tasks

import org.powbot.api.Condition
import org.powbot.api.Input
import org.powbot.api.Random
import org.powbot.api.rt4.Inventory
import org.powbot.api.rt4.Movement
import org.powbot.api.rt4.Objects
import org.powbot.om6.salvager.ShipwreckSalvager
import org.powbot.om6.salvager.LootConfig

class DropSalvageTask(
    script: ShipwreckSalvager,
    private val salvageItemName: String
) : Task(script) {

    private val useTapToDrop: Boolean
        get() = script.tapToDrop && script.isTapToDropEnabled

    override fun activate(): Boolean {
        // NEW LOGIC: If 'Sort Salvage (AFK)' is TRUE, this task should NOT activate.
        // LootManagementTask will handle the dropping instead.
        if (script.sortSalvageOnly) {
            script.logger.debug("ACTIVATE: DropSalvageTask suppressed because 'Sort Salvage (AFK)' is TRUE.")
            return false
        }

        script.logger.debug("ACTIVATE: Checking if phase is ${SalvagePhase.DROPPING_SALVAGE.name} (${script.currentPhase == SalvagePhase.DROPPING_SALVAGE}) or Inventory is full (${Inventory.isFull()}).")
        return script.currentPhase == SalvagePhase.DROPPING_SALVAGE || Inventory.isFull()
    }

    override fun execute() {
        script.logger.info("TASK: DROPPING_SALVAGE. Initiating manual drop sequence.")
        script.currentPhase = SalvagePhase.DROPPING_SALVAGE
        // Note: CrystalExtractorTask.checkAndExecuteInterrupt() is a helper function that attempts to run the extractor task
        if (CrystalExtractorTask(script).checkAndExecuteInterrupt()) { return }

        dropSalvageItems()

        if (CrystalExtractorTask(script).checkAndExecuteInterrupt()) { return }

        if (script.withdrawCargoOnDrop) {
            script.logger.info("LOGIC: 'Withdraw Cargo on Drop' enabled. Attempting cargo withdrawal.")
            withdrawCargo()
            // After withdrawal, we drop the salvage items again in case they were pulled from cargo
            dropSalvageItems()
        }

        // If inventory is not full, move to the waiting phase
        if (!Inventory.isFull()) {
            script.currentPhase = SalvagePhase.WAITING_FOR_RESPAWN
            script.phaseStartTime = System.currentTimeMillis()
            script.currentRespawnWait = Random.nextInt(
                ShipwreckSalvager.RESPAWN_WAIT_MIN_MILLIS,
                ShipwreckSalvager.RESPAWN_WAIT_MAX_MILLIS
            ).toLong()
            script.logger.info("PHASE CHANGE: Dropping complete. Transitioned to ${script.currentPhase.name}.")
        } else {
            script.logger.warn("FAIL: Inventory is still full after drop sequence. Retrying drop in next loop.")
        }
    }

    private fun dropSalvageItems() {
        script.logger.info("DROP: Looking for '$salvageItemName'...")
        val salvageItem = Inventory.stream().name(salvageItemName).firstOrNull()

        if (salvageItem != null) {
            if (useTapToDrop) {
                script.logger.info("DROP: Using tap-to-drop for '$salvageItemName'.")
                Inventory.open()
                salvageItem.click()
                Condition.wait({ Inventory.stream().name(salvageItemName).isEmpty() }, 100, 25)
            } else {
                script.logger.info("DROP: Using right-click drop for '$salvageItemName'.")
                Inventory.open()
                salvageItem.interact("Drop")
                Condition.wait({ Inventory.stream().name(salvageItemName).isEmpty() }, 100, 25)
            }
        } else {
            script.logger.info("DROP: Salvage item '$salvageItemName' not found in inventory. Proceeding.")
        }

        // Also drop other junk items if inventory is getting full
        script.logger.info("DROP: Dropping secondary junk items.")
        Inventory.stream().name(*LootConfig.DROP_LIST).forEach { item ->
            if (item.valid()) {
                Inventory.open()
                item.interact("Drop")
                Condition.wait({ item.valid() }, 100, 25) // Wait for item to be gone
            }
        }
    }

    /**
     * Executes a 3-tap sequence for quick Cargo Hold withdrawal using fixed screen coordinates.
     * Assumes a fixed camera angle (WEST) and specific UI layout.
     */
    private fun withdrawCargo() {
        val waitTime = Random.nextInt(900, 1200)

        fun getRandomOffsetLarge() = Random.nextInt(-6, 7)
        script.logger.info("CARGO: Starting 3-tap cargo withdrawal sequence.")

        // Tap 1: Open Cargo (302, 308)
        val x1 = 302 + getRandomOffsetLarge()
        val y1 = 308 + getRandomOffsetLarge()
        if (Input.tap(x1, y1)) {
            script.logger.info("CARGO TAP 1 (Open): Tapped at ($x1, $y1). Waiting $waitTime ms.")
            Condition.sleep(waitTime)
        } else {
            script.logger.warn("CARGO TAP 1 (Open): Tap at ($x1, $y1) failed.")
        }

        // Tap 2: Withdraw Cargo (143, 237)
        val x2 = 143 + getRandomOffsetLarge()
        val y2 = 237 + getRandomOffsetLarge()
        if (Input.tap(x2, y2)) {
            script.logger.info("CARGO TAP 2 (Withdraw): Tapped at ($x2, $y2). Waiting $waitTime ms.")
            Condition.sleep(waitTime)
        } else {
            script.logger.warn("CARGO TAP 2 (Withdraw): Tap at ($x2, $y2) failed.")
        }

        // Tap 3: Close (302, 308) - reuse open coordinates
        val x3 = 302 + getRandomOffsetLarge()
        val y3 = 308 + getRandomOffsetLarge()
        if (Input.tap(x3, y3)) {
            script.logger.info("CARGO TAP 3 (Close): Tapped at ($x3, $y3). Waiting $waitTime ms.")
            Condition.sleep(waitTime)
        } else {
            script.logger.warn("CARGO TAP 3 (Close): Tap at ($x3, $y3) failed.")
        }
    }
}