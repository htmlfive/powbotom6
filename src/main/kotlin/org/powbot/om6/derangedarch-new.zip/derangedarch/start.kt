package org.powbot.om6.derangedarch

fun main() {
    val script = DerangedArchaeologistMagicKiller()
    script.startScript("localhost", "0m6", false)
}